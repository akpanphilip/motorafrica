<div class="partners-section">
    <div class="container-padding">
        <p class="caption-title text-center">
            Trusted By
        </p>

        <div class="row m-50">
            <div class="col-md-6 col-lg-3 d-flex justify-content-center align-items-center">
                <img src={{ asset('assets/images/bolt.png') }} class="partner-logo" height="40" alt="partner_logo">
            </div>
            <div class="col-md-6 col-lg-3 d-flex justify-content-center align-items-center">
                <img src={{ asset('assets/images/thankucash.png') }} class="partner-logo" height="40"
                    alt="partner_logo">
            </div>
            <div class="col-md-6 col-lg-3 d-flex justify-content-center align-items-center">
                <img src={{ asset('assets/images/auto-check.png') }} class="partner-logo" height="40"
                    alt="partner_logo">
            </div>
            <div class="col-md-6 col-lg-3 d-flex justify-content-center align-items-center">
                <img src={{ asset('assets/images/one-pipe.png') }} class="partner-logo" height="40"
                    alt="partner_logo">
            </div>
        </div>
    </div>
</div>
</div>
