<div class="container-padding">
    <div class="signup-section" data-aos="fade-bottom" data-aos-duration="1500">
        <div>
            <p class="signup-title">
                Sign up for free & get started
            </p>
            <p class="signup-desc">
                Discover how the smart mobility revolution will transform <br> your business, today.
            </p>
        </div>
        <a href="" class="start-now-btn">
            {{-- data-aos="fade-left" data-aos-duration="1500" --}}
            start now
        </a>
    </div>
</div>
