<div class="hero-speed-monitoring">
    <div class="col-hero">
        <p class="hero-title text-center text-white">
            <span><a class="text-main-clr">Powerful Tool</a> Designed To Keep</span>
            <span>Your Fleet Moving At The Right Pace.</span>
        </p>

        <p class="hero-sub-title text-white text-center">
            <span>Gain control over vehicle speed and enhance driver behavior with our comprehensive</span>
            <span>speed monitoring solution.</span>
        </p>
        <div class="d-flex justify-content-center">
            <a href="" class="yellow-btn text-center">learn more</a>

        </div>
    </div>
</div>
