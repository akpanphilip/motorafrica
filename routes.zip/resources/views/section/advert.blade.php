<div class="advert-section">
    <div class="container-padding">
        <div class="row">
            <div class="col-md-12 col-lg-5">
                <div class="advert-in">
                    {{-- <p class="caption-caption">#BNPL</p> --}}
                    <p class="caption-title text-white"><span class="block-display">Simplifying</span> <span
                            class="block-display">collateralized micro</span>
                        lending for
                        Africans.</p>

                    <div class="hero-btns">
                        <a href="" class="hero-learn-more">get started</a>
                        <a href="" class="hero-book-demo border-white text-white hover-main-clr">learn more</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
