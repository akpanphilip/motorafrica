<div class="hero-about">
    <div class="container-padding">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <p class="hero-text-lg text-lighter">About <a class="text-main-clr">Us</a></p>
                <p class="hero-text-md text-lighter">
                    At <a class="text-main-clr">Motor Africa</a> we believe that creating sustainable solutions to Africa's transportation problems
                    is key to unlocking the continent's potential.
                </p>
            </div>
        </div>
    </div>


</div>
